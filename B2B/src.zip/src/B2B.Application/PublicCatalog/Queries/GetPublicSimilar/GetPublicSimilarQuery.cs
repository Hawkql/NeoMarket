﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using B2B.Application.PublicCatalog.Dtos;
using MediatR;

namespace B2B.Application.PublicCatalog.Queries.GetPublicSimilar
{
    public sealed record GetPublicSimilarQuery(Guid ProductId, int Limit)
    : IRequest<IReadOnlyList<ProductPublicShortDto>>;
}
