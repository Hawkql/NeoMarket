﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2B.Domain.Products
{
    public enum ProductStatus
    {
        Created = 0,
        OnModeration = 1,
        Moderated = 2,
        Blocked = 3,
        HardBlocked = 4,
    }
}
